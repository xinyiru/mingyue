<?php defined('IN_PHPCMS') or exit('No permission resources.'); ?>	<?php include template('content','header'); ?>
	<link rel="stylesheet" href="<?php echo CSS_PATH;?>mycss/index.css">
</head>
<body>
	<!-- 关于茗悦开始 -->
	<div class="zyh_about">
		<div class="zyh_logo"></div>
		<div class="zyh_text">
			<p>
				茗悦国艺成立于2009年，是一家当代专业的艺术文化产业传播机构，主要致力于中国茶文化及相关产品的生成与推广，其旗下拥
			</p>
			<p>
				有茗悦茶艺培训中心、从前慢手工茶器、茶空间设计中心等产业机构
			</p>
			<p>
				除了茶相关的茶艺培训、茶艺讲座、茶艺表演及相关茶产品，茗悦还拥有古琴、香道、花道、书法等传统文化系列课程培训。优越
			</p>
			<p>
				的学习环境、强大的师资团队、专业的服务理念，在整个行业内堪称典范；专业、高效、热情的做人做事宗旨，更为茗悦在业内和消
			</p>
			<p>
				费者之间树立了良好口碑。不懈的努力是对文化的专注，严苛的自我要求是对您的负责。
			</p>
			<p>
				传承经典，落脚现实，享受质朴，收货珍贵。
			</p>
		</div>
		<div class="zyh_img">
			<ul>
				<li style="width:664px;height:255px;margin-right:10px;">
					<a href="##">
						<img src="<?php echo IMG_PATH;?>myimages/zyh_gymy3.png" alt="">
					</a>
				</li>
				<li style="width:523px;height:255px;">
					<a href="##">
						<img src="<?php echo IMG_PATH;?>myimages/zyh_gymy4.png" alt="">
					</a>
				</li>	
			</ul>
			<ul>
				<li style="width:349px;height:255px;margin-right:10px;margin-bottom:0;">
					<a href="##">
						<img src="<?php echo IMG_PATH;?>myimages/zyh_gymy5.png" alt="">
					</a>
				</li>
				<li style="width:370px;height:255px;margin-right:10px;margin-bottom:0;">
					<a href="##">
						<img src="<?php echo IMG_PATH;?>myimages/zyh_gymy6.png" alt="">
					</a>
				</li>
				<li style="width:459px;height:255px;margin-right:0;margin-bottom:0;">
					<a href="##">
						<img src="<?php echo IMG_PATH;?>myimages/zyh_gymy7.png" alt="">
					</a>
				</li>	
			</ul>
		</div>
	</div>
	<!-- 关于茗悦结束 -->
	<!-- 培训课程开始 -->
	<div class="zyh_train">
		<div class="zyh_logo"></div>
		<ul class="zyh_title">
			<?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=2ca77d9942577f6d3fe4c6f0fa516417&action=category&order=listorder+ASC&catid=11\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'category')) {$data = $content_tag->category(array('order'=>'listorder ASC','catid'=>'11','limit'=>'20',));}?>
			<?php $n=1;if(is_array($data)) foreach($data AS $d) { ?>
			<li><a ><?php echo $d['catname'];?></a></li>
			<?php $n++;}unset($n); ?>
			<?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>
		</ul>
		<div class="zyh_xian"></div>
		<div class="zyh_img">
			<ul>
				<li  id="active" class="tn-zyh-btn1">
					<a href="<?php echo $CATEGORYS['21']['url'];?>">
						<img src="<?php echo IMG_PATH;?>myimages/zyh_gymy10.png" alt="">
						<span>JUNIOR CRADE TEA COURSE</span>
						<p>1初中级茶艺师课程</p>
					</a>
				</li>
				<li class="tn-zyh-btn1">
					<a href="<?php echo $CATEGORYS['21']['url'];?>">
						<img src="<?php echo IMG_PATH;?>myimages/zyh_gymy11.png" alt="">
						<span>SENIOR SPECIALIST TRAINING COURSES</span>
						<p>高级茶艺师培训课程</p>
					</a>
				</li>
				<li class="tn-zyh-btn1">
					<a href="<?php echo $CATEGORYS['21']['url'];?>">
						<img src="<?php echo IMG_PATH;?>myimages/zyh_gymy12.png" alt="">
						<span>PARENT-CHILD TEA COURSE</span>
						<p>亲子茶艺课程</p>
					</a>
				</li>
				<li class="tn-zyh-btn1">
					<a href="<?php echo $CATEGORYS['21']['url'];?>">
						<img src="<?php echo IMG_PATH;?>myimages/zyh_gymy13.png" alt="">
						<span>ONE OF A CLASS OF TEA BOUTIQUE</span>
						<p>一对一茶艺精品班课程</p>
					</a>
				</li>
			</ul>
			<ul>
				<li  id="active"  class="tn-zyh-btn2">
					<a href="<?php echo $CATEGORYS['22']['url'];?>">
						<img src="<?php echo IMG_PATH;?>myimages/zyh_gymy10.png" alt="">
						<span>JUNIOR CRADE TEA COURSE</span>
						<p>2初中级茶艺师课程</p>
					</a>
				</li>
				<li class="tn-zyh-btn2">
					<a href="<?php echo $CATEGORYS['22']['url'];?>">
						<img src="<?php echo IMG_PATH;?>myimages/zyh_gymy11.png" alt="">
						<span>SENIOR SPECIALIST TRAINING COURSES</span>
						<p>高级茶艺师培训课程</p>
					</a>
				</li>
				<li  class="tn-zyh-btn2">
					<a href="<?php echo $CATEGORYS['22']['url'];?>">
						<img src="<?php echo IMG_PATH;?>myimages/zyh_gymy12.png" alt="">
						<span>PARENT-CHILD TEA COURSE</span>
						<p>亲子茶艺课程</p>
					</a>
				</li>
				<li  class="tn-zyh-btn2">
					<a href="<?php echo $CATEGORYS['22']['url'];?>">
						<img src="<?php echo IMG_PATH;?>myimages/zyh_gymy13.png" alt="">
						<span>ONE OF A CLASS OF TEA BOUTIQUE</span>
						<p>一对一茶艺精品班课程</p>
					</a>
				</li>
			</ul>
			<ul>
				<li  id="active"  class="tn-zyh-btn3">
					<a href="<?php echo $CATEGORYS['23']['url'];?>">
						<img src="<?php echo IMG_PATH;?>myimages/zyh_gymy10.png" alt="">
						<span>JUNIOR CRADE TEA COURSE</span>
						<p>3初中级茶艺师课程</p>
					</a>
				</li>
				<li class="tn-zyh-btn3">
					<a href="<?php echo $CATEGORYS['23']['url'];?>">
						<img src="<?php echo IMG_PATH;?>myimages/zyh_gymy11.png" alt="">
						<span>SENIOR SPECIALIST TRAINING COURSES</span>
						<p>高级茶艺师培训课程</p>
					</a>
				</li>
				<li  class="tn-zyh-btn3">
					<a href="<?php echo $CATEGORYS['23']['url'];?>">
						<img src="<?php echo IMG_PATH;?>myimages/zyh_gymy12.png" alt="">
						<span>PARENT-CHILD TEA COURSE</span>
						<p>亲子茶艺课程</p>
					</a>
				</li>
				<li  class="tn-zyh-btn3">
					<a href="<?php echo $CATEGORYS['23']['url'];?>">
						<img src="<?php echo IMG_PATH;?>myimages/zyh_gymy13.png" alt="">
						<span>ONE OF A CLASS OF TEA BOUTIQUE</span>
						<p>一对一茶艺精品班课程</p>
					</a>
				</li>
			</ul>
			<ul>
				<li id="active" class="tn-zyh-btn4">
					<a href="<?php echo $CATEGORYS['24']['url'];?>">
						<img src="<?php echo IMG_PATH;?>myimages/zyh_gymy10.png" alt="">
						<span>JUNIOR CRADE TEA COURSE</span>
						<p>4初中级茶艺师课程</p>
					</a>
				</li>
				<li class="tn-zyh-btn4">
					<a href="<?php echo $CATEGORYS['24']['url'];?>">
						<img src="<?php echo IMG_PATH;?>myimages/zyh_gymy11.png" alt="">
						<span>SENIOR SPECIALIST TRAINING COURSES</span>
						<p>高级茶艺师培训课程</p>
					</a>
				</li>
				<li  class="tn-zyh-btn4">
					<a href="<?php echo $CATEGORYS['24']['url'];?>">
						<img src="<?php echo IMG_PATH;?>myimages/zyh_gymy12.png" alt="">
						<span>PARENT-CHILD TEA COURSE</span>
						<p>亲子茶艺课程</p>
					</a>
				</li>
				<li  class="tn-zyh-btn4">
					<a href="<?php echo $CATEGORYS['24']['url'];?>">
						<img src="<?php echo IMG_PATH;?>myimages/zyh_gymy13.png" alt="">
						<span>ONE OF A CLASS OF TEA BOUTIQUE</span>
						<p>一对一茶艺精品班课程</p>
					</a>
				</li>
			</ul>
		</div>
	</div>
	<!-- 培训课程结束 -->
	<!-- 讲座表演开始 -->
	<div class="tn-jzby">
		<div class="tn-logo"></div>
		<div class="tn-content">
			<div class="tn-content-tu">
				<img src="<?php echo IMG_PATH;?>myimages/tn-title2.jpg" alt="">
			</div>
			<div class="tn-content-zi">
				<span class="tn-span1">
					<i></i>2016.10.05
				</span>
				<h3>
					<span>ABOUT TEA</span>  CUL TURE
				</h3>
				<h4>当文化穿越回最初</h4>
				<p>作为当代专业的艺术文化产业传播机构，茗悦根植于东
					方传统美学，传承的同时融入现实的思考，究竟用什么
					方式来演绎璀璨了千年的东方美学？唯有将传统的
					外衣暂且脱下，<br>
					留下能真正代表东方经典的美学价值，</p>
				<a href="<?php echo $CATEGORYS['25']['url'];?>">
					<img src="" alt="">
				</a>
			</div>
		</div>
		<div class="tn-content">
			<div class="tn-content-tu" style="float: right;">
				<img src="<?php echo IMG_PATH;?>myimages/tn-title4.jpg" alt="">
			</div>
			<div class="tn-content-zi" style="float: left;">
				<span class="tn-span1">
					<i></i>2016.10.05
				</span>
				<h3>
					<span>ABOUT TEA</span>  CUL TURE
				</h3>
				<h4>当文化穿越回最初</h4>
				<p>作为当代专业的艺术文化产业传播机构，茗悦根植于东
					方传统美学，传承的同时融入现实的思考，究竟用什么
					方式来演绎璀璨了千年的东方美学？唯有将传统的
					外衣暂且脱下，<br>
					留下能真正代表东方经典的美学价值，</p>
				<a href="<?php echo $CATEGORYS['26']['url'];?>">
					<img src="" alt="">
				</a>
			</div>
		</div>
	</div>
	<!--讲座表演结束-->
	<!--大标题开始-->
	<div class="tn-dbt">
		<div class="tn-dbt-content"></div>
		<div class="tn-dbt-content">
			<span class="tn-span1">
				<i></i>2016.10.05
			</span>
			<h3>
				<span>ABOUT TEA</span>  CUL TURE
			</h3>
			<h4>功夫茶茶艺</h4>
			<p>近日，横岗街道怡锦社区党群服务中心举行了一场社区民生大盆
				菜之“礼赞父母·孝亲奉茶”活动，，<br>
				15名萌童身着汉服，手把茶具，跟着茶艺师演绎具有中华特色
				的传统华夏茶礼。这是“小小状元郎”国学 <br>
				书院中的一个项目。课堂上....</p>
		</div>
	</div>
	<!--大标题结束-->
	<!--最新动态开始-->
	<div class="tn-zxdt">
		<div class="tn-title"></div>
		<div class="tn-content">
			<ul class="tn-content_left">
				<?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=98ed5c8aee1e902c3a9fa1d38a562680&action=lists&catid=19&moreinfo=1&num=3&order=listorder+ASC\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'lists')) {$data = $content_tag->lists(array('catid'=>'19','moreinfo'=>'1','order'=>'listorder ASC','limit'=>'3',));}?>
				<?php $n=1;if(is_array($data)) foreach($data AS $c) { ?>
				<li>
					<!-- <img src="<?php echo IMG_PATH;?>myimages/zxdt_11.png" alt=""> -->
					<img src="<?php echo $c['thumb'];?>" alt="">

					<h3> ><?php echo $c['title'];?></h3>
					<p class="overmorethree">
						<?php echo $c['content'];?>
					</p>
					<a href="<?php echo $c['url'];?>">
						<img src="" alt="">
					</a>
				</li>
				<?php $n++;}unset($n); ?>
				<?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>
			</ul>
			<ul class="tn-content_right">
				<?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=98ed5c8aee1e902c3a9fa1d38a562680&action=lists&catid=19&moreinfo=1&num=3&order=listorder+ASC\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'lists')) {$data = $content_tag->lists(array('catid'=>'19','moreinfo'=>'1','order'=>'listorder ASC','limit'=>'3',));}?>
				<?php $i=0?>
				<?php $n=1;if(is_array($data)) foreach($data AS $b) { ?>
				<?php $i++; ?>
				<?php if($b[catid]==$catid) { ?>
				<li id="background-yy">
					<div class="zxdt-btn-title">
						<div class="redkuai"></div>
						<i <?php if($i==1) { ?>class="zxdt_btn1"<?php } elseif ($i==2) { ?>class="zxdt_btn1"<?php } else { ?>class="zxdt_btn3"<?php } ?>></i>
						<div class="zxdt-top">
							<i></i>
							<span>FEEDING KNOWLEDGE</span>
						</div>
						<h3>
							<!-- 古典与现代交融   调酒与茶艺邂逅 -->
							<?php echo $b['title'];?>
						</h3>
					</div>
					<p class="zxdt-content overmorethree">
						<!-- 一场古典与现代交融、碰撞的精彩绝伦的晚会在这里上演，该场晚会作为本届美食文化节最具特色的活动之一，调酒、茶艺、香艺等节目赢得观众阵阵喝彩。调酒师用变幻莫测的手法将各种酒的美释放得淋漓尽致， -->
						<?php echo $b['content'];?>
					</p>
				</li>
				<?php } else { ?>
				<li>
					<div class="zxdt-btn-title">
						<div class="redkuai"></div>
						<i <?php if($i==1) { ?>class="zxdt_btn1"<?php } elseif ($i==2) { ?>class="zxdt_btn2"<?php } else { ?>class="zxdt_btn3"<?php } ?>></i>
						<div class="zxdt-top">
							<i></i>
							<span>FEEDING KNOWLEDGE</span>
						</div>
						<h3>
							<?php echo $b['title'];?>
						</h3>
					</div>
					<p class="zxdt-content">
						<?php echo $b['content'];?>
					</p>
				</li>
				<?php } ?>
				<?php $n++;}unset($n); ?>
				<?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>
			</ul>
		</div>
	</div>
	<!--最新动态结束-->
	<!--教师团队开始-->
	<div class="yws_teacher">
		<div class="yws_title"></div>
		<div class="yws_contentbox">
			<ul class="yws_content yws_content1">
				<li class="yws_listbox">
					<div class="yws_imgbox">
						<div class="yws_img yws_img1"></div>
					</div>
					<div class="yws_des over">
						Famous tea
						<div class="box"></div>
					</div>
					<span>著名茶艺师1</span>
				</li>
				<li class="yws_listbox">
					<div class="yws_imgbox">
						<div class="yws_img yws_img2"></div>
					</div>
					<div class="yws_des over">
						Famous tea
						<div class="box"></div>
					</div>
					<span>著名茶艺师</span>
				</li>
				<li class="yws_listbox">
					<div class="yws_imgbox">
						<div class="yws_img yws_img3"></div>
					</div>
					<div class="yws_des over">
						Senior Guqin
						<div class="box"></div>
					</div>
					<span>高级古琴师</span>
				</li>
			</ul>
			<ul class="yws_content yws_content2">
				<li class="yws_listbox">
					<div class="yws_imgbox">
						<div class="yws_img yws_img1"></div>
					</div>
					<div class="yws_des over">
						Famous tea
						<div class="box"></div>
					</div>
					<span>著名茶艺师2</span>
				</li>
				<li class="yws_listbox">
					<div class="yws_imgbox">
						<div class="yws_img yws_img2"></div>
					</div>
					<div class="yws_des over">
						Famous tea
						<div class="box"></div>
					</div>
					<span>著名茶艺师</span>
				</li>
				<li class="yws_listbox">
					<div class="yws_imgbox">
						<div class="yws_img yws_img3"></div>
					</div>
					<div class="yws_des over">
						Senior Guqin
						<div class="box"></div>
					</div>
					<span>高级古琴师</span>
				</li>
			</ul>
			<ul class="yws_content yws_content3">
				<li class="yws_listbox">
					<div class="yws_imgbox">
						<div class="yws_img yws_img1"></div>
					</div>
					<div class="yws_des over">
						Famous tea
						<div class="box"></div>
					</div>
					<span>著名茶艺师3</span>
				</li>
				<li class="yws_listbox">
					<div class="yws_imgbox">
						<div class="yws_img yws_img2"></div>
					</div>
					<div class="yws_des over">
						Famous tea
						<div class="box"></div>
					</div>
					<span>著名茶艺师</span>
				</li>
				<li class="yws_listbox">
					<div class="yws_imgbox">
						<div class="yws_img yws_img3"></div>
					</div>
					<div class="yws_des over">
						Senior Guqin
						<div class="box"></div>
					</div>
					<span>高级古琴师</span>
				</li>
			</ul>
		</div>
		<ul class="yws_lunbobox">
			<li>
				<div></div>
			</li>
			<li>
				<div></div>
			</li>
			<li id="yws_active">
				<div></div>
			</li>
		</ul>
	</div>
	<!--教师团队结束-->
	<!--学员风采开始-->
	<div class="yws_student">
		<div class="yws_studenttitle"></div>
		<div class="yws_content">
			<ul class="yws_imgbox">
				<li class="yws_img ywsImg" id="img1"><a href=""></a></li>
				<li class="yws_img ywsImg" id="img2"><a href=""></a></li>
				<li class="yws_img ywsImg" id="img3"><a href=""></a></li>
			</ul>
		</div>
		<ul class="yws_lunbobox">
			<li>
				<div></div>
			</li>
			<li id="yws_active">
				<div></div>
			</li>
			<li>
				<div></div>
			</li>
		</ul>
	</div>
	<!--学员风采结束-->

<script src="<?php echo JS_PATH;?>myjs/index.js"></script>
<?php include template('content','footer'); ?>