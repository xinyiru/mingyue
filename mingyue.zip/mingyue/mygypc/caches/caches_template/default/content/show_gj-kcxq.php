<?php defined('IN_PHPCMS') or exit('No permission resources.'); ?>	<?php include template('content','header'); ?>
<link rel="stylesheet" href="<?php echo CSS_PATH;?>mycss/gj-kcxq.css">

	<title>课程详情页面</title>
</head>
<body>
<section>
	<div class="ljk"><a href="">您的位置：</a>
		<a href="<?php echo siteurl($siteid);?>">首页</a>>  
		<a href="javascript:;"><?php echo catpos($catid);?></a>
		</div>
	<div class="tb over">
		<?php echo $title;?>
	</div>
<div class="hg"></div>
<!-- 字段框开始 -->
<div class="zdk">
	<p>壹  何为茶艺</p>
	<p>（1）茶艺概述</p>
	<p>
（2）中国茶艺六要素茶艺是茶道这一普遍概念下属的子概念，它</p>
	<p>是指在茶事活动中的以茶叶为中心的全部操作形式的总称 ，了解茶艺的范畴</p>
	<p>及其六要素是我们习茶的基础。</p>
	<p>貳  正确识茶</p>
	<p>（1）茶叶起源</p>
	<p>（2）茶叶基础
</p>
	<p>（3）茶叶分类有好茶喝，会喝好茶，是一种“清福”，不过要享“清福”首</p>
	<p>先必须了解茶为何物，正确识茶对习茶来说是一门必修课。</p>
	<p>叁  科学泡茶</p>
	<p>（1）习茶礼仪</p>
	<p>（2）泡茶用水</p>
	<p>（3）泡茶用器-玻璃杯泡法、盖碗泡法、紫砂壶泡法的泡茶是一门学问，将对茶的认识延伸到</p>
	<p>泡好的“茶汤”上，才是茶艺在技能上的体现</p>
	<p>肆  专业评茶</p>
	<p>（1）綠茶专题</p>
	<p>（2）黃茶专题</p>
	<p>（3）白茶专题</p>
	<p>（4）红茶专题</p>
	<p>（5）青茶专题</p>
	<p>
（6）黑茶专题从色、香、味、形、嫩度、叶底等方面详细地解读了茶之</p>
	<p>
间的差异，有助于我们比较全面地认识和欣赏所有的茶 。</p>
	<p>伍  健康饮茶</p>
	<p>（1）看茶喝茶</p>
	<p>（2）看人喝茶</p>
	<p>
（3）看时喝茶饮茶对我们人体健康和陶冶情操有着不可取代的作用，但是我们不能盲</p>
	<p>目的饮茶，学会健康的饮茶，才能产生意想不到的效果</p>
	<p>陆  茶空间布置</p>
	<p>茶席是泡茶和喝茶的平台，学习了专业的茶道知识同时也要了解一些茶空间设计的</p>
	<p> 
元素，布置一片属于自己的茶空间，在此空间内品味初心。</p>
	<p>  （本文阅读：53次） </p>
	<img src="<?php echo IMG_PATH;?>myimages/mygytb.png" alt="">
</div>
</section>
<!-- 底部开始-->
<!-- 底部结束 -->
<?php include template('content','footer'); ?>