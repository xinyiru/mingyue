<?php defined('IN_PHPCMS') or exit('No permission resources.'); ?>	<?php include template('content','header'); ?>
	<link rel="stylesheet" href="<?php echo CSS_PATH;?>mycss/zyh_xyfc.css">
</head>
<body>
	<!-- 关于茗悦 学员风采 开始-->
	<div class="zyh_about">
		<!-- 导航开始 -->
		<div class="zyh_nav">
			<p>您的位置：</p>
			<a href="<?php echo siteurl($siteid);?>">
				首页 > 
			</a>
			<span><?php echo catpos($catid);?></span>
		</div>
		<!-- 导航结束 -->
		<div class="zyh_logo"></div>
		<!-- 标题开始 -->
		<div class="htt_jjheadbox">
			<ul class="htt_head" style="width: 650px;">
				<?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=2e2532fc96573b37a6f7b634a4f079c5&action=category&order=listorder+ASC&catid=%24top_parentid\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'category')) {$data = $content_tag->category(array('order'=>'listorder ASC','catid'=>$top_parentid,'limit'=>'20',));}?>
				<?php $i=0?>
				<?php $n=1;if(is_array($data)) foreach($data AS $d) { ?>
				<?php $i++; ?>
				<li <?php if($i==1) { ?>class="htt_menu htt_huawen" <?php } else { ?>class="htt_menu"<?php } ?> >
					<a href="<?php echo $d['url'];?>"><?php echo $d['catname'];?></a>
				</li>
				<?php $n++;}unset($n); ?>
				<?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>
			</ul>
		</div>
		<!-- 标题结束 -->
		<!-- 内容开始 -->
		<div class="zyh_js">
			<div class="zyh_navs">
				<?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=8c65f7450ac2f299cb85df92e462fddb&action=lists&catid=%24catid&num=6&moreinfo=1&order=listorder+ASC&page=%24page\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'lists')) {$pagesize = 6;$page = intval($page) ? intval($page) : 1;if($page<=0){$page=1;}$offset = ($page - 1) * $pagesize;$content_total = $content_tag->count(array('catid'=>$catid,'moreinfo'=>'1','order'=>'listorder ASC','limit'=>$offset.",".$pagesize,'action'=>'lists',));$pages = pages($content_total, $page, $pagesize, $urlrule);$data = $content_tag->lists(array('catid'=>$catid,'moreinfo'=>'1','order'=>'listorder ASC','limit'=>$offset.",".$pagesize,'action'=>'lists',));}?>
				<?php $i=0?>
				<?php $n=1;if(is_array($data)) foreach($data AS $e) { ?>
				<?php $i++; ?>
				<li <?php if($i==1) { ?>class="lis hide"<?php } else { ?>class="lis"<?php } ?>>
					<p>01</p>
					<p><?php echo date('Y-m-d',$e[inputtime]);?></p>
					<a href="<?php echo $e['url'];?>">
						<img src="<?php echo $e['thumb'];?>" alt="">
					</a>
					<p><?php echo $e['title'];?></p>
					<p class='overmoretwo'><?php echo $e['content'];?></p>
				</li>
				<?php $n++;}unset($n); ?>
				<?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>
			</div>
		</div>
		
		<!-- 内容结束 -->
		<!-- 底部开始 -->
		<div class="zyh_footer">
			<a href="##">
				<img src="<?php echo IMG_PATH;?>myimages/zyh_xyfc13.png" alt="">
			</a>
			<p>
				茶是一种起源于中国的由茶树植物或芽制作的饮品，也泛指可用于泡茶的常绿灌木茶树的叶子茶是一种起源。
			</p>
			<img src="<?php echo IMG_PATH;?>myimages/zyh_xyfc14.png" alt="" class="san">
		</div>
	</div>
<script src="<?php echo JS_PATH;?>myjs/htt.js"></script>
<?php include template('content','footer'); ?>