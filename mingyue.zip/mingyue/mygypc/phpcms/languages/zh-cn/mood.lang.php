<?php
$LANG['id_cannot_be_empty'] = 'ID不能为空';
$LANG['total'] = '总数';
$LANG['expressed'] = '你已经表达过心情了，保持平常心有益身体健康！';
$LANG['category'] = '栏目';
$LANG['time'] = '时间';
$LANG['sort'] = '排序';
$LANG['today'] = '今天';
$LANG['yesterday'] = '昨天';
$LANG['this_week'] = '本周';
$LANG['this_month'] = '本月';
$LANG['all'] = '所有';
$LANG['view'] = '查看';
$LANG['title'] = '标题';
$LANG['on_hand'] = '可用';
$LANG['name'] = '名称';
$LANG['pic'] = '图片';