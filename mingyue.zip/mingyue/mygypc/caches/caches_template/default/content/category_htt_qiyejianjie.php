<?php defined('IN_PHPCMS') or exit('No permission resources.'); ?>	<?php include template('content','header'); ?>
	<link rel="stylesheet" href="<?php echo CSS_PATH;?>mycss/htt.css">
</head>
<body>
	<!-- 企业简介正文导航开始 -->
	<div class="htt_weiz">
		<div class="htt_wz-l">
			<p>你的位置</p>
			<span>:</span>
			<a href="">首页</a>
			<span>&gt;</span>
			<a href="">关于茗悦</a>
			<span>&gt;</span>
			<a href="">企业简介</a>
			<span>&gt;</span>
			<a href="">正文</a>
		</div>
	</div>
	<!-- 企业简介正文导航结束 -->
	<!-- 企业简介正文选项卡开始 -->
	<div class="htt_jjheadbox">
		<ul class="htt_head" style="width: 650px;">
			<?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=2e2532fc96573b37a6f7b634a4f079c5&action=category&order=listorder+ASC&catid=%24top_parentid\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'category')) {$data = $content_tag->category(array('order'=>'listorder ASC','catid'=>$top_parentid,'limit'=>'20',));}?>
			<?php $i=0?>
			<?php $n=1;if(is_array($data)) foreach($data AS $d) { ?>
			<?php $i++; ?>
			<li <?php if($i==1) { ?>class="htt_menu htt_huawen"<?php } else { ?>class="htt_menu"<?php } ?>>
				<a href="<?php echo $d['url'];?>"><?php echo $d['catname'];?></a>
			</li>
			<?php $n++;}unset($n); ?>
			<?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>
		</ul>
	</div>
	<div class="htt_zhiya">至雅生活，茗悦同行 / FOODEXPO</div>
	<div class="htt_server">SERVER ORGANIZATION OF TEA</div>
	<div class="htt_inbox">
		<h3>IN TAYUAN</h3>
		<a href=""></a>
	</div>
<div class="htt_xxkbox">
<!-- 选项卡内容一 -->
	<div class="htt_xxkcon htt_active">
		<div class="htt_zoujin">
			<h4>走进茗悦国艺</h4>
			<span>/&nbsp; MING YUE GUOYI APPROACHED</span>
		</div>
		<p class="htt_cwh1">作为当代专业的艺术文化产业传播机构，茗悦根植于东方传统美学，传承的同时融入现实的思考，究竟用什么方式来演绎璀璨了千年的东方美学？唯有将传统的外衣暂且脱下，留下能真正代表东方经典的美学价值，再契合当代生活方式加以佐佑，创造出属于这个时代、这个民族的独特美学，才能使更多的人理解、接受、适应并推崇这潜藏在血液里的东方文明。
		</p>
		<p class="htt_cwh2">
		譬如茶道。作为一个有着五千年文化渊源的泱泱大国，从古至今，国人对传统茶道的深厚情愫始终未减。茗悦立足拥有几千年历史根基的中国茶文化，深谙茶道的同时更关注当代茶人的现实需求。茗悦人懂茶、爱茶、品茶、识茶，他们以满腔热情认真地做着和“茶”相关的事，默默奉献并乐在其中。昔日“陆放翁晴窗戏分茶”，“贾宝玉品茶栊翠庵”；今天，茗悦则选择了从现实的角度出发，重新对茶进行定义、研究、品鉴、赏味，以求真正领会、融通普悦“茶人合一，法道自然”的深远内涵。我们希望，在普悦身上，令国人骄傲的茶文化能焕发出新的生机，让更多人品悟到代表中国的经典味道。
		</p>
		<div class="htt_zoujin">
			<h4>茗悦国艺文化</h4>
			<span>/&nbsp; MING YUE GUOYI APPROACHED</span>
		</div>
		<p class="htt_cwh1">
		茗悦国艺于2009年成立，主要致力于中国茶文化及相关产品的生成及推广，旗下拥有茗悦茶艺培训中心、从前慢手工茶器、茶空间设计中心等产业机构。除了与茶相关的茶艺培训、茶艺讲座、茶艺表演及相关茶产品，茗悦还拥有古琴、香道、花道、书法等传统文化系列课程培训。优越的学习环境、强大的师资团队、专业的服务理念，在整个行业内堪称典范；专业、高效、热情的做人做事宗旨，更为茗悦在业内和消费者之间树立了良好口碑。不懈的努力是对文化的专注，严苛的自我要求是对您的负责。
		</p>
		<p class="htt_cwh2">
		从古至今，国人对传统茶道的深厚情愫始终未减。茗悦立足拥有几千年历史根基的中国茶文化，深谙茶道的同时更关注当代茶人的现实需求。茗悦人懂茶、爱茶、品茶、识茶，他们以满腔热情认真地做着和“茶”相关的事，默默奉献并乐在其中。昔日“陆放翁晴窗戏分茶”，“贾宝玉品茶栊翠庵”；今天，茗悦则选择了从现实的角度出发，重新对茶进行定义、研究、品鉴、赏味，以求真正领会、融通普悦“茶人合一，法道自然”的深远内涵。我们希望，在普悦身上，令国人骄傲的茶文化能焕发出新的生机，，让更多人品悟到代表中国的经典味道。
		</p>

		<!-- 企业简介正文选项卡结束 -->
		<!-- 茶艺文化图片开始 -->
		<div class="htt_cwhtubox">
			<div class="htt_chatul">
				<img src="<?php echo IMG_PATH;?>myimages/htt_cy1.png" alt="">
			</div>
			<div class="htt_chatur">
				<div class="htt_chatur1">
					<img src="<?php echo IMG_PATH;?>myimages/htt_cy2.png" alt="">
				</div>
				<div class="htt_chatur2">
					<img src="<?php echo IMG_PATH;?>myimages/htt_cy3.png" alt="">
				</div>
			</div>
		</div>
		<!-- 茶艺文化图片结束 -->
		<!-- 茗悦国艺企业的点滴开始 -->
		<div class="htt_qyddbox">
			<div class="htt_qydd">
			<h2>茗悦国艺企业的点滴</h2>
			<span> / MING YUE GUOYI ENTERPRISE BIT</span>
			</div>
			<p class="htt_cwh3">
				至雅生活，茗悦同行！让自己遇见更美的自己，让文化照进生活。走近茗悦国艺，去开启一个未知的全新蜕变。传承经典，落脚现实，享受质朴，收获珍贵。我们希望，在普悦身上，令国人骄傲的茶文化能焕发出新的生机，让更多人品悟到代表中国的经典味道。
			</p>
		</div>
		<div class="htt_myspbox">
			<div class="htt_daspzz"></div>
			<a href="" class="htt_playa">
				<div class="htt_spbtn"></div>
				<div class="htt_btny1"></div>
				<div class="htt_btny2"></div>
				<div class="htt_sanjiao"></div>
			</a>
			<h3 class="htt_miao">1'23</h3>
		</div>
	</div>
</div>
<!-- 茗悦国艺企业的点滴结束 -->

<!-- 底部logo开始 -->
	<div class="htt_lg1">
		<div class="htt_logo">
			
		</div>
	</div>
	<!-- 底部logo结束 -->
<script src="<?php echo JS_PATH;?>myjs/htt.js"></script>
<?php include template('content','footer'); ?>