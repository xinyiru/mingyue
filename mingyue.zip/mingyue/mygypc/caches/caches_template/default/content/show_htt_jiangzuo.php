<?php defined('IN_PHPCMS') or exit('No permission resources.'); ?>	<?php include template('content','header'); ?>
	<link rel="stylesheet" href="<?php echo CSS_PATH;?>mycss/htt.css">
</head>
<body>
	<!-- 讲座表演导航开始 -->
	<div class="htt_weiz">
		<div class="htt_wz-l">
			<p>你的位置</p>
			<span>:</span>
			<a href="<?php echo siteurl($siteid);?>">首页</a>
			<span>&gt;</span>
			<a href="javascript:;"><?php echo catpos($catid);?></a>
		</div>
	</div>
	<!-- 讲座表演导航结束 -->
	<!-- 功夫茶茶艺开始 -->
	<div class="htt_zz-box">
		<?php echo $title;?>
	</div>
	<!-- 功夫茶茶艺结束 -->
	<!-- 功夫茶茶艺下面的线开始 -->
	<div class="htt_chaxian">
		<div class="htt_xiany1"></div>
		<div class="htt_xiany2"></div>
	</div>
	<!-- 功夫茶茶艺下面的线结束 -->
	<!-- 功夫茶茶艺表演开始 -->
	<div class="htt_gfbox">
		<div class="htt_erc">
			<div class="htt_cybox">
				<h2 class="over"><<?php echo $title;?>></h2>
			</div>
			<div class="htt_bftime">
				<div class="htt_jiaplay"></div>
				<span>:</span>
				<h3>213</h3>
			</div>
		</div>
		<div class="htt_spbox">
			<div class="htt_sp">
				<div class="htt_spzz"></div>
				<a href="" class="htt_an">
					<img src="<?php echo IMG_PATH;?>myimages/htt_play.png" alt="">
				</a>
			</div>
		</div>
		<div class="htt_anbox"></div>
		<div class="htt_fxbox">
			<div class="htt_fxl">
				<div class="htt_fxtu">
					<a href=""><img src="<?php echo IMG_PATH;?>myimages/htt_fx.png" alt=""></a>
				</div>
				<div class="htt_fxdd">
					<a href=""><img src="<?php echo IMG_PATH;?>myimages/htt_dd.png" alt=""></a>
				</div>
				<div class="htt_fxwb">
					<a href=""><img src="<?php echo IMG_PATH;?>myimages/htt_wb.png" alt=""></a>
				</div>
				<div class="htt_fxqq">
					<a href=""><img src="<?php echo IMG_PATH;?>myimages/htt_qq.png" alt=""></a>
				</div>
				<div class="htt_fxwx">
					<a href=""><img src="<?php echo IMG_PATH;?>myimages/htt_wx.png" alt=""></a>
				</div>
			</div>
			<div class="htt_fxr">
				<span>上传于<?php echo $inputtime;?></span><span class="htt_sr">上传人:嘻哈小子</span>
			</div>
		</div>
	</div>
	<!-- 功夫茶茶艺表演结束 -->
	<!-- 花茶的讲解上一篇开始 -->
	<div class="htt_hcjjbox">
		<div class="htt_hcjj">
			<h2 class="over"><a href="<?php echo $previous_page['url'];?>" class="over">上一篇:<?php echo $previous_page['title'];?></a></h2>
			<h3 class="over"><a href="<?php echo $next_page['url'];?>" class="over">上一篇:<?php echo $next_page['title'];?></a></h3>
		</div>
	</div>
	<!-- 花茶的讲解上一篇结束 -->
	<!-- 相关视频开始 -->
	<div class="htt_xguanbox">
		<div class="htt_xgsp">
			<div class="htt_xgspl">
				<div class="htt_xiaoj"></div>
				<div class="htt_xgspzi">
					<h2>相关<span>视频</span></h2>
					<h3>RELATED VIDEO</h3>
				</div>	
			</div>
			<div class="htt_xgspr">
				<h4><a href="<?php echo $CATEGORYS['12']['url'];?>">更多精彩&gt;</a></h4>
			</div>
		</div>
		<div class="htt_spconbox">
			<div class="htt_spkc1">
				<div class="htt_zz"></div>
				<p class="htt_p1">大师课堂--白茶</p>
				<p class="htt_p2">如何鉴别白茶</p>
				<p class="htt_p3">播放次数:123次</p>
				<button><a href="">立即播放</a></button>
				<div class="htt_heic">大师课堂--白茶</div>
			</div>
			<div class="htt_spkc2">
				<button><a href="">立即播放</a></button>
				<div class="htt_zz"></div>
				<p class="htt_p1">大师课堂--黑茶</p>
				<p class="htt_p2">如何鉴别黑茶</p>
				<p class="htt_p3">播放次数:231次</p>
				<div class="htt_heic">大师课堂--黑茶</div>
			</div>
		</div>
	</div>
	<!-- 相关视频结束 -->
<!-- </div> -->
	<!-- 底部logo开始 -->
	<div class="htt_dblogo">
		<div class="htt_logo">
			
		</div>
	</div>
	<!-- 底部logo结束 -->
<?php include template('content','footer'); ?>