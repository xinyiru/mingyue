<?php
return array (
  1 => 
  array (
    'siteid' => '1',
    'name' => '默认站点',
    'dirname' => '',
    'domain' => 'http://localhost/mygypc/',
    'site_title' => 'PHPCMS演示站',
    'keywords' => 'PHPCMS演示站',
    'description' => 'PHPCMS演示站',
    'release_point' => '',
    'default_style' => 'default',
    'template' => 'default',
    'setting' => 'array (
  \'upload_maxsize\' => \'2048\',
  \'upload_allowext\' => \'jpg|jpeg|gif|bmp|png|doc|docx|xls|xlsx|ppt|pptx|pdf|txt|rar|zip|swf\',
  \'watermark_enable\' => \'1\',
  \'watermark_minwidth\' => \'300\',
  \'watermark_minheight\' => \'300\',
  \'watermark_img\' => \'/statics/images/water/mark.png\',
  \'watermark_pct\' => \'85\',
  \'watermark_quality\' => \'80\',
  \'watermark_pos\' => \'9\',
)',
    'uuid' => '7f657c14-078a-11e7-8f74-8cdcd47b1135',
    'url' => 'http://localhost/mygypc/',
  ),
);
?>