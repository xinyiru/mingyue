<?php defined('IN_PHPCMS') or exit('No permission resources.'); ?><?php include template('content','header'); ?>
	<link rel="stylesheet" href="<?php echo CSS_PATH;?>mycss/zq-kecheng.css">
</head>
<body>
	<!-- 关于茗悦 学员风采 开始-->
	<div class="zyh_about">
		<!-- 导航开始 -->
		<div class="zyh_nav">
			<p>您的位置：</p>
			<a href="">
				首页 >关于茗悦>企业简介>正文
			</a>
		</div>
		<!-- 导航结束 -->
		<div class="zyh_logo"></div>
		<!-- 标题开始 -->
		<div class="htt_jjheadbox">
			<ul class="htt_head" style="width: 650px;">
				<?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=2e2532fc96573b37a6f7b634a4f079c5&action=category&order=listorder+ASC&catid=%24top_parentid\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'category')) {$data = $content_tag->category(array('order'=>'listorder ASC','catid'=>$top_parentid,'limit'=>'20',));}?>
				<?php $i=0?>
				<?php $n=1;if(is_array($data)) foreach($data AS $d) { ?>
				<?php $i++; ?>
				<li <?php if($i==1) { ?>class="htt_menu htt_huawen"<?php } else { ?>class="htt_menu"<?php } ?>>
					<a href="<?php echo $d['url'];?>"><?php echo $d['catname'];?></a>
				</li>
				<?php $n++;}unset($n); ?>
				<?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>
			</ul>
		</div>
		<!-- 标题结束 -->
		<!-- 内容开始 -->
		<ul class="zq-listbox">
			<?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=c20c54d016f0c7d9e70eccc9b24f5b2c&action=lists&catid=%24catid&moreinfo=1&num=6&order=listorder+ASC&page=%24page\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'lists')) {$pagesize = 6;$page = intval($page) ? intval($page) : 1;if($page<=0){$page=1;}$offset = ($page - 1) * $pagesize;$content_total = $content_tag->count(array('catid'=>$catid,'moreinfo'=>'1','order'=>'listorder ASC','limit'=>$offset.",".$pagesize,'action'=>'lists',));$pages = pages($content_total, $page, $pagesize, $urlrule);$data = $content_tag->lists(array('catid'=>$catid,'moreinfo'=>'1','order'=>'listorder ASC','limit'=>$offset.",".$pagesize,'action'=>'lists',));}?>
			<?php $n=1;if(is_array($data)) foreach($data AS $f) { ?>
			<li class="zq-list active">
				<img src="<?php echo $f['thumb'];?>" alt="">
				<div class="zq-listright">
					<h4><?php echo $f['title'];?></h4>
					<p class="zq-han overmoretwo"><?php echo $f['description'];?></p>
					<p class="zq-eng overmorethree"><?php echo $f['content'];?></p>
					<a href="<?php echo $f['url'];?>"><img src="<?php echo IMG_PATH;?>myimages/zq-more.png" alt=""></a>
				</div>
			</li>
			<?php $n++;}unset($n); ?>
			<?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>
		</ul>
		<div class="zq-listbot">
			<div class="zq-heng">
				<div class="zq-hengkuai"></div>
			</div>
			<div class="zq-zi">
				<p>让自己遇见更美的自己，让文化照进生活。走近茗悦国艺，去开启一个未知的全新蜕变</p>
				<p>至雅生活，茗悦同行</p>
			</div>
		</div>

<script src="<?php echo JS_PATH;?>myjs/htt.js"></script>
<?php include template('content','footer'); ?>