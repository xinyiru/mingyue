<?php  
defined('IN_PHPCMS') or exit('Access Denied');
defined('INSTALL') or exit('Access Denied');
return array('comment', 'comment_check', 'comment_data', 'comment_setting', 'comment_table');
?>