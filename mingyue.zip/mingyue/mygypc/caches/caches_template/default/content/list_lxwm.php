<?php defined('IN_PHPCMS') or exit('No permission resources.'); ?><?php include template('content','header'); ?>
<link rel="stylesheet" href="<?php echo CSS_PATH;?>mycss/gj-lxwm.css">
<script src="<?php echo JS_PATH;?>myjs/jquery.min.js"></script>
	<title>联系我们</title>
</head>
<body>
<!-- 头部开始 -->
	<header></header>
<!-- 头部结束 -->
<!-- banner开始 -->
<!-- banner结束 -->
<section>
<div class="ljk">
	<a href="">&nbsp&nbsp您的位置：</a>
	<a href="">首页 ></a>
	<a href="">关于茗悦 ></a>
	<a href="">企业介绍 ></a>
	<a href=""> 正文</a></div>
	<div class="tb"></div>
<div class="hk">
	<div class="lk">
		<img src="<?php echo IMG_PATH;?>myimages/db.png" alt="">
		<img src="<?php echo IMG_PATH;?>myimages/phone.png" alt="">
		<img src="<?php echo IMG_PATH;?>myimages/message.png" alt="">
		
	</div>
	<p>太原 / 迎泽区 / 柳巷 / 303号</p>
		<p>Add</p>
		<p>400-0351-152</p>
		<p>Tel</p>
		<p>7890351@qq.com</p>
		<p>Email</p>
	<img src="<?php echo IMG_PATH;?>myimages/ditu.png" alt="" class="uu">
<!-- 需要提交数据的地方 -->
	<div class="xk">
     <!-- <form action=""></form> -->
	 <select name="select" id="select_k1" class="xla_k" placeholder="报名课程：">
       <option value="选择品牌">&nbsp报名课程：茶艺培训1</option>
       <option value="选择品牌1">&nbsp报名课程：茶艺培训2</option>
        <option value="选择品牌2">&nbsp报名课程：选择品牌3</option>
    </select>
    <input type="text" placeholder="&nbsp您的姓名:" class="dd" >
    <input type="text" placeholder="&nbsp微信号码:" class="db">
    <input type="text" placeholder="&nbsp联系电话:" class="dc">
    <input type="button" class="xx">
    <input type="button" class="lx">
    
    <input type="text"placeholder="留言:"class="gc"style="text-align:left;padding-top:0;">
	</div>
<!-- 提交结束 -->
</div>	
</section>
<script src="<?php echo JS_PATH;?>myjs/jquery.min.js"></script>
<script>
	var xx=document.getElementsByClassName('xx');
	var lx=document.getElementsByClassName('lx');
	 $(document).ready(function(e){
            /*点击删除 清空输入框的内容*/
            $('.lx').click(function(){
                $('.xk input').val('');
            });
             $('.xx').click(function(){
                $('.xk input').val('');
            });

        });
     
</script>
<?php include template('content','footer'); ?>