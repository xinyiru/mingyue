<?php defined('IN_PHPCMS') or exit('No permission resources.'); ?>	<link rel="stylesheet" href="<?php echo CSS_PATH;?>mycss/footer.css">
	<!-- 在线报名开始 -->
	<div class="yws_online">
		<div class="onlinebox">
			<div class="online0"></div>
			<div class="bao">
				<div class="logo"></div>
				<div class="input">
					<span>报名课程 :</span>
					<select>
						<option value="online">茶艺培训</option>
						<option value="online1">香道培训</option>
						<option value="online2">插花培训</option>
						<option value="online3">古琴培训</option>
					</select>
				</div>
				<div class="input">
					<span>您的姓名 :</span>
					<input type="text" name="name">
				</div>
				<div class="input">
					<span>微信号码 :</span>
					<input type="text" name="wechat">
				</div>
				<div class="input">
					<span>联系电话 :</span>
					<input type="text" name="number">
				</div>
				<div class="liuyan">
					<span>留言 :</span>
					<textarea></textarea>
				</div>
				<input class="submit" type="submit" value="提交报名">
			</div>
			<div class="online1"></div>
		</div>
	</div>
	<!-- 在线报名结束 -->
	<!-- footerBegin -->
	<footer class="yws_footer">
		<div class="yws_topbox">
			<div class="yws_top">
				<div class="first">
					<p class="yws_call">联系我们</p>
					<p class="company">company  US</p>
					<p class="server">服务热线</p>
					<p class="phone">400-0351-152</p>
				</div>
				<div class="second">
					<a href="">茶艺</a>
					<a href="">古琴</a>
					<a href="">喝茶</a>
					<a href="">茶艺师</a>
					<a href="">香道</a>
					<a href="">泡茶</a>
					<a href="">茶道</a>
					<a class="last" href="">茶艺知识</a>
				</div>
				<div class="third">
					<img src="<?php echo IMG_PATH;?>myimages/wechat.png" alt="">
					<p class="wechat">微信公众号</p>
				</div>
			</div>
		</div>
		<div class="yws_bottom">
			<p class="yws_left">@ 2016 chawenhua.cn Corporation. All Rights Reserved.</p>
			<p class="yws_right">晋ICP备14008682号-10</p>
		</div>
	</footer>
	<!-- footerOver -->
</body>
<script src="<?php echo JS_PATH;?>myjs/footer.js"></script>
</html>