<?php defined('IN_PHPCMS') or exit('No permission resources.'); ?><!doctype html>
<html lang="en">
<head> 
    <meta charset="UTF-8">
    <meta name="renderer" content="webkit"/>
    <meta tnp-equiv="X-UA-COMPATIBLE" content="IE-Edge">
    <title>Document</title>
    <link rel="stylesheet" href="<?php echo CSS_PATH;?>mycss/bass.css">
    <link rel="stylesheet" href="<?php echo CSS_PATH;?>mycss/header.css">
</head>
<body>
<!--***********************************头部开始********************************-->
<header class="tn_head">
    <div class="tn_head_con">
        <div class="tn_logo"></div>
        <ul class="tn_nav">
            <li class="tn_menu">
                <a href="<?php echo siteurl($siteid);?>">首页</a>
            </li>
            <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=fc8830a494e50ec728f3a559662a05ff&action=category&catid=0&siteid=%24siteid&order=listorder+ASC\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">修改</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'category')) {$data = $content_tag->category(array('catid'=>'0','siteid'=>$siteid,'order'=>'listorder ASC','limit'=>'20',));}?>
            <?php $n=1;if(is_array($data)) foreach($data AS $a) { ?>
            <?php if($a[catid]==$catid) { ?>
            <li class="tn_menu">
                <a href="<?php echo $a['url'];?>" class="tn_bj"><?php echo $a['catname'];?></a>
            </li>
            <?php } else { ?>
            <li class="tn_menu">
                <a href="<?php echo $a['url'];?>"><?php echo $a['catname'];?></a>
            </li>
            <?php } ?>
            <?php $n++;}unset($n); ?>
            <?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>
        </ul>
        <div class="tn_rex"></div>
    </div>
</header>
<!--***********************************头部结束********************************-->
<!--***********************************banner开始******************************-->
<div class="banner-box">
    <div class="banner">
        <div class="banner-tu banner1"></div>
        <div class="banner-tu banner2"></div>
        <div class="banner-tu banner3"></div>
    </div>
    <div class="banner-btn-box">
        <div class="banner-btn" id="btn-color"></div>
        <div class="banner-btn"></div>
        <div class="banner-btn"></div>
    </div>
</div>
<!--***********************************banner结束******************************-->
<script src="<?php echo JS_PATH;?>myjs/header.js"></script>
