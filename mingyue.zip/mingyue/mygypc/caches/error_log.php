<?php exit;?>03-13 09:12:54 | 2 | array_keys() expects parameter 1 to be array, boolean given | phpcms\libs\functions\global.func.php | 1499
<?php exit;?>03-13 09:12:54 | 2 | in_array() expects parameter 2 to be array, null given | phpcms\libs\functions\global.func.php | 1500
<?php exit;?>03-13 09:12:54 | 2 | array_keys() expects parameter 1 to be array, boolean given | phpcms\libs\functions\global.func.php | 1499
<?php exit;?>03-13 09:12:54 | 2 | in_array() expects parameter 2 to be array, null given | phpcms\libs\functions\global.func.php | 1500
<?php exit;?>03-13 09:12:54 | 2 | array_keys() expects parameter 1 to be array, boolean given | phpcms\libs\functions\global.func.php | 1499
<?php exit;?>03-13 09:12:54 | 2 | in_array() expects parameter 2 to be array, null given | phpcms\libs\functions\global.func.php | 1500
<?php exit;?>03-13 09:12:54 | 2 | array_keys() expects parameter 1 to be array, boolean given | phpcms\libs\functions\global.func.php | 1499
<?php exit;?>03-13 09:12:54 | 2 | in_array() expects parameter 2 to be array, null given | phpcms\libs\functions\global.func.php | 1500
<?php exit;?>03-13 09:12:54 | 2 | array_keys() expects parameter 1 to be array, boolean given | phpcms\libs\functions\global.func.php | 1499
<?php exit;?>03-13 09:12:54 | 2 | in_array() expects parameter 2 to be array, null given | phpcms\libs\functions\global.func.php | 1500
<?php exit;?>03-13 09:12:54 | 2 | array_keys() expects parameter 1 to be array, boolean given | phpcms\libs\functions\global.func.php | 1499
<?php exit;?>03-13 09:12:54 | 2 | in_array() expects parameter 2 to be array, null given | phpcms\libs\functions\global.func.php | 1500
<?php exit;?>03-13 09:12:54 | 2 | array_keys() expects parameter 1 to be array, boolean given | phpcms\libs\functions\global.func.php | 1499
<?php exit;?>03-13 09:12:54 | 2 | in_array() expects parameter 2 to be array, null given | phpcms\libs\functions\global.func.php | 1500
<?php exit;?>03-13 09:12:54 | 2 | array_keys() expects parameter 1 to be array, boolean given | phpcms\libs\functions\global.func.php | 1499
<?php exit;?>03-13 09:12:54 | 2 | in_array() expects parameter 2 to be array, null given | phpcms\libs\functions\global.func.php | 1500
<?php exit;?>03-13 09:12:54 | 2 | array_keys() expects parameter 1 to be array, boolean given | phpcms\libs\functions\global.func.php | 1499
<?php exit;?>03-13 09:12:54 | 2 | in_array() expects parameter 2 to be array, null given | phpcms\libs\functions\global.func.php | 1500
<?php exit;?>03-13 09:12:54 | 2 | array_keys() expects parameter 1 to be array, boolean given | phpcms\libs\functions\global.func.php | 1499
<?php exit;?>03-13 09:12:54 | 2 | in_array() expects parameter 2 to be array, null given | phpcms\libs\functions\global.func.php | 1500
<?php exit;?>03-13 09:12:54 | 2 | array_keys() expects parameter 1 to be array, boolean given | phpcms\libs\functions\global.func.php | 1499
<?php exit;?>03-13 09:12:54 | 2 | in_array() expects parameter 2 to be array, null given | phpcms\libs\functions\global.func.php | 1500
<?php exit;?>03-13 09:12:54 | 2 | array_keys() expects parameter 1 to be array, boolean given | phpcms\libs\functions\global.func.php | 1499
<?php exit;?>03-13 09:12:54 | 2 | in_array() expects parameter 2 to be array, null given | phpcms\libs\functions\global.func.php | 1500
<?php exit;?>03-13 09:12:54 | 2 | array_keys() expects parameter 1 to be array, boolean given | phpcms\libs\functions\global.func.php | 1499
<?php exit;?>03-13 09:12:54 | 2 | in_array() expects parameter 2 to be array, null given | phpcms\libs\functions\global.func.php | 1500
<?php exit;?>03-13 09:12:54 | 2 | array_keys() expects parameter 1 to be array, boolean given | phpcms\libs\functions\global.func.php | 1499
<?php exit;?>03-13 09:12:54 | 2 | in_array() expects parameter 2 to be array, null given | phpcms\libs\functions\global.func.php | 1500
<?php exit;?>03-13 09:12:54 | 2 | array_keys() expects parameter 1 to be array, boolean given | phpcms\libs\functions\global.func.php | 1499
<?php exit;?>03-13 09:12:54 | 2 | in_array() expects parameter 2 to be array, null given | phpcms\libs\functions\global.func.php | 1500
<?php exit;?>03-13 09:12:54 | 2 | mysqli::mysqli():              | phpcms\libs\classes\db_mysqli.class.php | 55
<?php exit;?>03-13 09:12:54 | 2 | db_mysqli::error(): Couldn't fetch mysqli | phpcms\libs\classes\db_mysqli.class.php | 390
<?php exit;?>03-13 09:12:54 | 2 | db_mysqli::errno(): Couldn't fetch mysqli | phpcms\libs\classes\db_mysqli.class.php | 397
<?php exit;?>03-13 09:12:54 | 2 | db_mysqli::errno(): Couldn't fetch mysqli | phpcms\libs\classes\db_mysqli.class.php | 397
<?php exit;?>03-13 09:12:54 | 2 | db_mysqli::error(): Couldn't fetch mysqli | phpcms\libs\classes\db_mysqli.class.php | 390
<?php exit;?>03-13 09:12:54 | 2 | mysqli::close(): Couldn't fetch mysqli | phpcms\libs\classes\db_mysqli.class.php | 409
<?php exit;?>03-13 09:13:03 | 2 | mysqli::mysqli():              | phpcms\libs\classes\db_mysqli.class.php | 55
<?php exit;?>03-13 09:13:03 | 2 | db_mysqli::error(): Couldn't fetch mysqli | phpcms\libs\classes\db_mysqli.class.php | 390
<?php exit;?>03-13 09:13:03 | 2 | db_mysqli::errno(): Couldn't fetch mysqli | phpcms\libs\classes\db_mysqli.class.php | 397
<?php exit;?>03-13 09:13:03 | 2 | db_mysqli::errno(): Couldn't fetch mysqli | phpcms\libs\classes\db_mysqli.class.php | 397
<?php exit;?>03-13 09:13:03 | 2 | db_mysqli::error(): Couldn't fetch mysqli | phpcms\libs\classes\db_mysqli.class.php | 390
<?php exit;?>03-13 09:13:03 | 2 | mysqli::close(): Couldn't fetch mysqli | phpcms\libs\classes\db_mysqli.class.php | 409
<?php exit;?>03-13 09:15:18 | 2 | Missing argument 2 for category::delete_child(), called in C:\wamp\www\mygypc\phpcms\modules\admin\category.php on line 351 and defined | phpcms\modules\admin\category.php | 346
<?php exit;?>03-13 09:16:30 | 2 | Invalid argument supplied for foreach() | phpcms\libs\classes\tree.class.php | 216
