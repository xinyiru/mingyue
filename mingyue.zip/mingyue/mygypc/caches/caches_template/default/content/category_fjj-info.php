<?php defined('IN_PHPCMS') or exit('No permission resources.'); ?><?php include template('content','header'); ?>
  <link rel="stylesheet" href="<?php echo CSS_PATH;?>mycss/list-newinfo.css">
</head>
<body>
   <!-- 面包屑导航 -->
  <div class="fjj-bread-nav">
    <span>您的位置:</span>
    <a href="#">首页</a>
    <span>&gt;</span>
    <a href="#">最新动态</a>
    <span>&gt;</span>
    <a href="#">茗悦动态</a>
  </div>
  <!-- end面包屑导航 -->
 <!-- title  pic -->
  <div class="fjj-listtitle-pic">
    <!-- //标题图片 -->
    <img class="title-pic" src="<?php echo IMG_PATH;?>myimages/fjj-images/fjj-new-title.png" alt="">
  </div>
  <!-- end title pic -->
  <!-- 切换区域 -->
  <!-- 当前的那个页面的a链接加类名active -->
    <div class="htt_jjheadbox">
    <ul class="htt_head">
      <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=2e2532fc96573b37a6f7b634a4f079c5&action=category&order=listorder+ASC&catid=%24top_parentid\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'category')) {$data = $content_tag->category(array('order'=>'listorder ASC','catid'=>$top_parentid,'limit'=>'20',));}?>
      <?php $i=0?>
      <?php $n=1;if(is_array($data)) foreach($data AS $d) { ?>
      <?php $i++; ?>
      <li <?php if($i==1) { ?>class="htt_menu htt_huawen"<?php } else { ?>class="htt_menu"<?php } ?>>
        <a href="<?php echo $d['url'];?>"><?php echo $d['catname'];?></a>
      </li>
      <?php $n++;}unset($n); ?>
      <?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>
    </ul>
  </div>
  <!-- end切换区域 -->
  <!-- 选项卡        默认第一个子元素显示在前 类名加active-->
  <ul class="fjj-box">
    <li class="fjj-item">
      <!-- 列表区域 -->
      <!-- 列表第二项加一个类名col2 -->
      <ul class="fjj-info-list">
        <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=c20c54d016f0c7d9e70eccc9b24f5b2c&action=lists&catid=%24catid&moreinfo=1&num=6&order=listorder+ASC&page=%24page\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'lists')) {$pagesize = 6;$page = intval($page) ? intval($page) : 1;if($page<=0){$page=1;}$offset = ($page - 1) * $pagesize;$content_total = $content_tag->count(array('catid'=>$catid,'moreinfo'=>'1','order'=>'listorder ASC','limit'=>$offset.",".$pagesize,'action'=>'lists',));$pages = pages($content_total, $page, $pagesize, $urlrule);$data = $content_tag->lists(array('catid'=>$catid,'moreinfo'=>'1','order'=>'listorder ASC','limit'=>$offset.",".$pagesize,'action'=>'lists',));}?>
        <?php $n=1;if(is_array($data)) foreach($data AS $e) { ?>
        <li class="item">
          <!-- a标签转到对应的内容详情页 -->
          <a href="<?php echo $e['url'];?>">
          <!-- 图片 -->
            <div class="pic">
              <img src="<?php echo $e['thumb'];?>" alt="">
            </div>
            <!-- 标题 -->
            <h1><?php echo $e['title'];?></h1>
            <!-- 描述 -->
            <p class="desc">
              <?php echo $e['content'];?>
            </p>
            <!-- 日期 -->
            <p class="time">-<?php echo date('Y.m.d',$e[inputtime]);?>-</p>
            <!-- 序号 -->
            <span class="num">01</span>
          </a>
        </li>
        <?php $n++;}unset($n); ?>
        <?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>
      </ul>
      <!-- end 列表区域 -->


      <!-- $pages区域 -->
      <div class="fjj-pages">
        <div class="inner">
          <?php echo $pages;?>
        </div>
      </div>
      <!-- end $pages区域 -->
    </li>
  </ul>
  <!-- 选项卡结束 -->
  <!-- //底部文字 -->
  <div class="fjj-list-bottom">
    <p class="line"></p>
    <p class="content">让自己遇见更美的自己,让文化照进生活。走进茗悦国艺，去开启一个未知的全新蜕变<br>至雅生活,茗悦同行</p>
  </div>
  <!-- end 底部文字 -->

  <!-- //选项卡的js -->
  <script src="<?php echo JS_PATH;?>myjs/htt.js"></script>
<?php include template('content','footer'); ?>
